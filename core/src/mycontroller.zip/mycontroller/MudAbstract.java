package mycontroller;

public class MudAbstract extends TrapAbstract{
	
/* * * * * * METHODS * * * * * */
	
	//String representation of the tile
	@Override
	public String toString(){
		return "%";
	}

}
