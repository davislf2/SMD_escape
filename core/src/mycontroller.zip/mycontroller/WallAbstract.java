package mycontroller;

public class WallAbstract extends TileAbstract{
	
/* * * * * * METHODS * * * * * */
	
	//String representation of the tile
	@Override
	public String toString(){
		return "X";
	}

}
