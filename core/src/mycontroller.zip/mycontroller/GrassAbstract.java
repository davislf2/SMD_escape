package mycontroller;

public class GrassAbstract extends TrapAbstract{
	
/* * * * * * METHODS * * * * * */
	
	//String representation of the tile
	@Override
	public String toString(){
		return "#";
	}

}
